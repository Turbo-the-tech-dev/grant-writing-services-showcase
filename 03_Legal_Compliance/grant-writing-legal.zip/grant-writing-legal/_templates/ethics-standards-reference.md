# Professional Ethics & Standards Reference

---

## Grant Professionals Association (GPA) — Code of Ethics

*The primary professional body for grant writers. Full code at grantprofessionals.org.*

### Core Obligations

| Standard | Practical Meaning for Solo Consultants |
|----------|---------------------------------------|
| Accurate representation of credentials | Do not overstate win rates, certifications, or experience |
| Contingency fee prohibition | Never tie your fee to a % of award — it's unethical and often violates funder terms |
| Conflict of interest disclosure | Disclose any personal/financial relationship with funder or board member |
| Confidentiality | Protect all client information as described in your contract |
| Funder relationship integrity | Do not misrepresent your relationship with funders |
| Honest assessment | If a client is not fundable, say so — don't take the money |

### GPA Membership & Credentials

| Credential | Requirement | Value |
|-----------|------------|-------|
| GPA Member | Annual dues | Access to ethics standards, community |
| Grant Professional Certified (GPC) | Exam + experience | Industry's primary certification |

---

## Prohibited Fee Arrangements

The following fee structures are prohibited by GPA, AFP, and many funders:

| Arrangement | Why Prohibited |
|------------|---------------|
| % of award (e.g., 5% of grant awarded) | Creates perverse incentives; violates funder terms; often illegal in federal grants |
| Success fee contingent on award | Same as above |
| Kickbacks from funder connections | Clear ethical violation |
| Fee waived in exchange for board seat or gift | Conflict of interest |

**Document this clearly in your contract.** Some clients will ask for contingency pricing. The answer is always no.

---

## Conflict of Interest Situations — Decision Tree

**Do you have a personal, financial, or professional relationship with:**
- The funder being approached?
- A funder program officer?
- A board member of the client organization?
- A vendor being named in the grant budget?

**If yes:**
1. Stop work on that application
2. Disclose the relationship in writing to the client immediately
3. Let the client decide whether to proceed with another consultant for that specific funder
4. Document your disclosure

---

## Honest Assessment Obligation

Before taking on any engagement, conduct a brief fundability check:

☐ Does the client's mission align with the funder's stated priorities?
☐ Does the client meet minimum eligibility requirements?
☐ Does the client have the organizational capacity to manage the grant?
☐ Are financials stable enough that funders won't be concerned?
☐ Is there a realistic program to fund, or is this purely an idea?

**If the answer to multiple items is "no" — say so.** Taking on unfundable clients harms your win rate, your reputation, and the client's resources. A brief "I don't think this is the right fit and here's why" conversation is the ethical and business-smart move.

---

## Disclosure Templates

### Conflict of Interest Disclosure Email
> Subject: Conflict of Interest Disclosure — [Funder Name]
>
> Hi [Client Name],
>
> Before we proceed with the [Funder Name] application, I want to disclose that I have [describe relationship — e.g., "a prior working relationship with the program officer at this foundation"]. While I believe I can prepare a strong proposal, I want to ensure you're aware of this connection so you can make an informed decision about whether you'd like me to proceed or assign this particular funder to a different consultant.
>
> Please let me know how you'd like to handle this.
>
> [Your Name]

---

## Maintaining Your Credentials

| Activity | Frequency | Notes |
|----------|-----------|-------|
| GPA membership renewal | Annual | Maintain current membership to use GPC designation |
| GPC continuing education | Every 3 years | 45 hours required for recertification |
| Professional development log | Ongoing | Track workshops, webinars, conferences |
| Ethics refresher | Annual | Review GPA Code of Ethics |

---

## Professional Development Log

| Date | Activity | Provider | Hours | CE Credit? |
|------|---------|---------|-------|-----------|
| | | | | |
