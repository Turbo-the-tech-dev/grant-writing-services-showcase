# Grant Consulting Services Agreement
*Master Template — v2.0 | Last Reviewed: [Date]*

> Attorney review recommended before use. This template covers core risk areas for solo grant consultants.

---

**AGREEMENT** entered into as of **[DATE]** between:

**CONSULTANT:** [Your Full Legal Name / LLC Name], [State] [entity type]
Address: [Address], [City, State, ZIP]
EIN: [XX-XXXXXXX]
("Consultant")

**CLIENT:** [Organization Legal Name], a [state] [nonprofit corporation / other]
Address: [Address], [City, State, ZIP]
Primary Contact: [Name, Title, Email]
("Client")

---

## ARTICLE 1 — SERVICES

### 1.1 Scope of Work
Consultant agrees to perform the grant writing and consulting services described in **Exhibit A** (Statement of Work), attached hereto and incorporated by reference.

### 1.2 Changes to Scope
Any changes to the scope of services must be documented in a written **Change Order** signed by both parties before additional work commences. Verbal agreements to expand scope do not obligate Consultant to perform additional work.

### 1.3 Standard of Care
Consultant will perform services in a professional manner consistent with industry standards. Consultant makes no warranty, express or implied, beyond this standard.

---

## ARTICLE 2 — COMPENSATION & PAYMENT

### 2.1 Fees
Client agrees to pay Consultant the fees set forth in Exhibit A.

### 2.2 Invoicing & Payment Terms
Invoices are due within **[15/30] days** of the invoice date. Invoices unpaid after [30] days accrue interest at **1.5% per month** (18% annually) on the outstanding balance.

### 2.3 Deposit
A non-refundable deposit of **[50]%** of the total project fee is due upon execution of this Agreement. Work will not commence until the deposit is received.

### 2.4 Expenses
Pre-approved out-of-pocket expenses (travel, postage, printing) will be billed at cost with documentation. Consultant's standard business tools and software are not billable.

### 2.5 Disputed Invoices
Client must notify Consultant in writing of any disputed invoice within **7 days** of receipt. Undisputed portions must be paid by the due date.

---

## ARTICLE 3 — CLIENT OBLIGATIONS

### 3.1 Information & Cooperation
Client shall provide accurate and complete organizational data, financials, program information, and supporting materials necessary for Consultant to perform services. Client warrants that all information provided is truthful and accurate.

### 3.2 Review & Approval Timelines
Client agrees to review and return feedback on drafts within **[5] business days**. Delays caused by Client that affect submission deadlines are not the responsibility of Consultant.

### 3.3 Authorized Representative
Client designates [Name, Title] as its authorized representative with authority to approve deliverables and bind the organization under this Agreement.

### 3.4 Compliance with Funder Requirements
Client is solely responsible for ensuring its organization meets all eligibility requirements of any funder to which Consultant submits on its behalf. Consultant does not independently verify organizational eligibility.

---

## ARTICLE 4 — NO GUARANTEE OF FUNDING

**CLIENT EXPRESSLY ACKNOWLEDGES THAT GRANT WRITING SERVICES DO NOT GUARANTEE THE AWARD OF GRANT FUNDING.** Funding decisions are made solely at the discretion of funders. Consultant's fees are earned upon delivery of agreed services and are due regardless of funding outcome.

---

## ARTICLE 5 — CONTINGENCY FEES PROHIBITED

Consultant does not accept compensation contingent upon grant award amounts. Any arrangement tying Consultant's compensation to a percentage of funds awarded is prohibited under the ethical standards of the Grant Professionals Association and Association of Fundraising Professionals, and may violate funder terms and conditions.

---

## ARTICLE 6 — INTELLECTUAL PROPERTY

### 6.1 Work Product Ownership
Upon receipt of full payment, all written deliverables produced under this Agreement become the sole property of Client. No rights transfer until payment is received in full.

### 6.2 Consultant's Pre-Existing Materials
Consultant retains all rights to pre-existing tools, frameworks, templates, and methodologies used in the performance of services. Client receives a license to use deliverables but not the underlying templates.

### 6.3 Portfolio Use
Consultant may reference the engagement (client name, grant type, outcome if publicly known) in professional portfolio materials and proposals, unless Client requests otherwise in writing within 30 days of project completion.

### 6.4 Third-Party Content
Client warrants that any materials provided to Consultant for incorporation into grant documents (photos, data, reports) do not infringe third-party intellectual property rights. Client indemnifies Consultant against any claims arising from Client-provided content.

---

## ARTICLE 7 — CONFIDENTIALITY

### 7.1 Obligations
Each party agrees to hold the other's Confidential Information in strict confidence, use it only for purposes of this Agreement, and not disclose it to third parties without prior written consent.

### 7.2 Definition
"Confidential Information" means all non-public information disclosed by either party, including financials, donor data, program strategies, and proprietary methodologies.

### 7.3 Exceptions
Confidentiality obligations do not apply to information that: (a) becomes publicly known through no breach of this Agreement; (b) was rightfully known before disclosure; (c) is independently developed; or (d) is required to be disclosed by law or court order (with prompt written notice to the other party).

### 7.4 Duration
Confidentiality obligations survive termination of this Agreement for a period of **3 years**.

---

## ARTICLE 8 — DATA SECURITY

### 8.1 Security Standards
Consultant will maintain reasonable administrative, technical, and physical safeguards to protect Client data, including use of password-protected accounts, encrypted cloud storage, and limited access to confidential files.

### 8.2 Data Retention & Deletion
Consultant will retain project files for **[3] years** following project completion, after which files will be securely deleted. Client may request earlier deletion in writing.

### 8.3 Breach Notification
In the event of a known or suspected data breach affecting Client information, Consultant will notify Client within **72 hours** of discovery.

---

## ARTICLE 9 — INDEPENDENT CONTRACTOR

Consultant is an independent contractor. Nothing in this Agreement creates an employment, partnership, joint venture, or agency relationship. Consultant is solely responsible for all taxes, benefits, and insurance applicable to Consultant's own business. Consultant retains the right to perform services for other clients concurrently.

---

## ARTICLE 10 — REPRESENTATIONS & WARRANTIES

### Client Warrants:
- It is a legally organized entity in good standing
- It has authority to enter into this Agreement
- All information provided to Consultant is accurate and not misleading
- It meets funder eligibility requirements for any grant pursued

### Consultant Warrants:
- It has the expertise and authority to perform the services
- Services will be performed professionally and in good faith
- No conflicts of interest exist that would impair performance

---

## ARTICLE 11 — LIMITATION OF LIABILITY

**IN NO EVENT SHALL CONSULTANT BE LIABLE FOR INDIRECT, INCIDENTAL, SPECIAL, OR CONSEQUENTIAL DAMAGES, INCLUDING LOST GRANT FUNDING, LOST PROFITS, OR REPUTATIONAL HARM, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.**

Consultant's total aggregate liability under this Agreement shall not exceed the **total fees paid by Client in the 90 days preceding the claim**.

---

## ARTICLE 12 — INDEMNIFICATION

Client agrees to indemnify, defend, and hold harmless Consultant from any claims, damages, or expenses (including reasonable attorney fees) arising from: (a) Client's breach of this Agreement; (b) inaccurate or misleading information provided by Client; (c) Client's failure to meet funder eligibility requirements; or (d) Client-provided content that infringes third-party rights.

---

## ARTICLE 13 — TERMINATION

### 13.1 Termination for Convenience
Either party may terminate this Agreement upon **[14] days** written notice. Client will be invoiced for all work completed and expenses incurred through the termination date. Deposits are non-refundable.

### 13.2 Termination for Cause
Either party may terminate immediately upon written notice if the other materially breaches this Agreement and fails to cure the breach within **7 days** of written notice.

### 13.3 Effect of Termination
Upon termination, Consultant will deliver all completed work product to Client (conditioned on payment). Sections covering IP, confidentiality, limitation of liability, and governing law survive termination.

---

## ARTICLE 14 — DISPUTE RESOLUTION

### 14.1 Good Faith Negotiation
Before initiating formal proceedings, both parties agree to attempt resolution through good faith negotiation for **30 days** following written notice of a dispute.

### 14.2 Mediation
If negotiation fails, the parties agree to non-binding mediation through [JAMS / AAA / local mediation service] before litigation.

### 14.3 Governing Law & Venue
This Agreement is governed by the laws of the State of **[YOUR STATE]**, without regard to conflict of law principles. Any litigation shall be brought in [County] County, [State].

### 14.4 Attorney Fees
In any dispute arising under this Agreement, the prevailing party is entitled to recover reasonable attorney fees and costs.

---

## ARTICLE 15 — GENERAL PROVISIONS

- **Entire Agreement:** This Agreement, including all Exhibits, constitutes the entire agreement between the parties and supersedes all prior discussions.
- **Amendments:** Modifications must be in writing signed by both parties.
- **Severability:** If any provision is found unenforceable, the remainder continues in full force.
- **Waiver:** Failure to enforce any provision is not a waiver of future enforcement rights.
- **Force Majeure:** Neither party is liable for delays caused by circumstances beyond reasonable control (natural disasters, government actions, etc.).
- **Notices:** Notices must be in writing and sent to the addresses above by email (with read receipt) or certified mail.
- **Counterparts:** This Agreement may be signed in counterparts or electronically, each of which shall be deemed an original.

---

## SIGNATURES

**CONSULTANT:**
Signature: ___________________________ Date: __________
Printed Name: [Your Name]
Title: Grant Consultant / [Member/Owner]

**CLIENT:**
Signature: ___________________________ Date: __________
Printed Name: ___________________________
Title: ___________________________
Organization: [Client Organization Name]

---

## EXHIBIT A — STATEMENT OF WORK

**Project:** [Grant Name / Program]
**Funder:** [Funder Name]
**Submission Deadline:** [Date]

### Deliverables

| # | Deliverable | Description | Due Date |
|---|------------|-------------|---------|
| 1 | | | |
| 2 | | | |
| 3 | | | |

### Revision Rounds Included: [X]

### Fees & Payment Schedule

| Milestone | Amount | Due |
|-----------|--------|-----|
| Deposit (50%) | $ | Upon signing |
| Final delivery | $ | Upon delivery of final draft |
| **Total** | **$** | |

### Exclusions
The following are outside scope and will require a separate Change Order:
- [List explicitly excluded items]
