# Change Order / Scope Amendment

**Change Order #:** CO-[YYYY]-[###]
**Date:** [Date]
**Original Agreement Date:** [Date]
**Client:** [Client Name]
**Project:** [Project / Grant Name]

---

## Description of Change

| | Original Scope | Amended Scope |
|--|---------------|--------------|
| Services | [Original description] | [New/additional description] |
| Deliverables | [Original] | [Amended] |
| Timeline | [Original deadline] | [New deadline] |

---

## Fee Adjustment

| | Amount |
|--|--------|
| Original Contract Fee | $ |
| Additional Fee for This Change | $ |
| **Revised Total Contract Value** | **$** |

**Additional fee due:** ☐ Upon signing this Change Order ☐ Upon delivery of revised deliverable

---

## Timeline Adjustment (if applicable)

| Milestone | Original Date | Revised Date |
|-----------|--------------|-------------|
| [Deliverable] | | |
| [Submission] | | |

---

## Reason for Change

[ ] Client-requested additional services
[ ] Funder added requirements after original agreement
[ ] Project complexity greater than anticipated
[ ] Other: _______________

---

## Agreement

Both parties agree that this Change Order modifies the original Service Agreement dated [DATE] and is incorporated by reference. All other terms of the original Agreement remain in full force.

**CONSULTANT:**
Signature: ___________________________ Date: __________
Name: [Your Name]

**CLIENT:**
Signature: ___________________________ Date: __________
Name: ___________________________
Title: ___________________________
