# Active Contracts Log

| Contract # | Client | Signed Date | Service Type | Contract Value | End Date / Term | Change Orders | Status | File Location |
|------------|--------|------------|--------------|---------------|----------------|--------------|--------|---------------|
| CONTRACT-2026-001 | Westside Community Foundation | 2025-09-01 | Retainer (12-mo) | $42,000 | 2026-08-31 | None | Active | active/CONTRACT-2026-001_Westside.pdf |
| CONTRACT-2026-002 | Clearwater Health Initiative | 2026-01-01 | Retainer (6-mo) | $12,000 | 2026-06-30 | None | Active | active/CONTRACT-2026-002_Clearwater.pdf |
| CONTRACT-2026-003 | Metro Arts Collective | 2026-01-10 | Project Fee | $2,800 | On delivery | None | Active | active/CONTRACT-2026-003_MetroArts.pdf |

---

## Contracts Pending Signature

| Client | Sent Date | Amount | Follow-Up Date | Notes |
|--------|-----------|--------|----------------|-------|
| | | | | |

---

## Renewal Pipeline

| Client | Current Term End | Renewal Discussion Due | Likely Renewal? | Notes |
|--------|-----------------|----------------------|----------------|-------|
| Westside Community Foundation | 2026-08-31 | 2026-07-01 | Yes | Strong relationship |
| Clearwater Health Initiative | 2026-06-30 | 2026-05-15 | TBD | Evaluate performance |
