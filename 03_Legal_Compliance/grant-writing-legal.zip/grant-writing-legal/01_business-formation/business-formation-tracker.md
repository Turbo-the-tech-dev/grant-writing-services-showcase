# Business Formation & Licensing Tracker

## Business Entity Information

| Field | Value |
|-------|-------|
| Legal Business Name | |
| DBA / Trade Name (if any) | |
| Entity Type | ☐ Sole Proprietor ☐ LLC ☐ S-Corp ☐ Other |
| State of Formation | |
| Date of Formation | |
| EIN (Federal Tax ID) | |
| State Tax ID | |
| NAICS Code | 541611 — Administrative Management Consulting |
| Fiscal Year End | December 31 |

---

## Registered Agent

| Field | Value |
|-------|-------|
| Registered Agent Name | |
| Address | |
| Phone / Email | |
| Annual Fee | $ |
| Renewal Date | |

---

## Licenses & Registrations

| License / Registration | Issuing Authority | License # | Issue Date | Expiration | Renewal Fee |
|----------------------|------------------|-----------|------------|-----------|------------|
| City / County Business License | [City/County] | | | | $ |
| State Business License (CA) | CA Secretary of State | | | | $ |
| LLC Statement of Information (CA) | CA Secretary of State | N/A | | Every 2 years | $20 |
| Fictitious Business Name (DBA) | County Clerk | | | 5 years | $ |

---

## LLC Operating Agreement Summary
*(Store the full signed document in this folder)*

| Section | Summary |
|---------|---------|
| Members | [Your Name] — 100% member |
| Management | Member-managed |
| Distributions | At member's discretion |
| Dissolution | Member vote |
| Date Executed | |
| Attorney Who Drafted | |

---

## Key Government Portals

| Portal | URL | Purpose |
|--------|-----|---------|
| CA Secretary of State | bizfileonline.sos.ca.gov | Annual filings, entity lookup |
| IRS EFTPS | eftps.gov | Federal tax payments |
| CA FTB | ftb.ca.gov | State estimated taxes |
| CA CDTFA | cdtfa.ca.gov | Sales tax (if applicable) |
| SAM.gov | sam.gov | Federal contractor registration (if pursuing federal work) |

---

## SAM.gov Registration (Federal Grants / Contracts)

| Field | Value |
|-------|-------|
| UEI (Unique Entity ID) | |
| CAGE Code | |
| Registration Date | |
| Expiration Date | |
| Annual Renewal Reminder | Set calendar alert 60 days before expiration |

> SAM.gov registration is required to receive federal awards or contracts.
> It must be renewed annually and kept active continuously.
