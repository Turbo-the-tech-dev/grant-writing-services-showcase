# Insurance Coverage Tracker

> Insurance is non-negotiable for a solo consultant. A single client dispute or data breach
> without coverage can be financially catastrophic.

---

## Active Policies

### Professional Liability / Errors & Omissions (E&O)

| Field | Value |
|-------|-------|
| Insurer | |
| Policy Number | |
| Agent / Broker | |
| Coverage Limit | $ per claim / $ aggregate |
| Deductible | $ |
| Annual Premium | $ |
| Policy Period | [Start Date] – [End Date] |
| Renewal Date | |
| Coverage Description | Covers claims arising from professional services, errors, omissions, or negligent acts |

**Why E&O matters for grant writers:** A client whose proposal was declined could (even without merit) allege your work was substandard. E&O pays defense costs and settlements.

---

### General Liability

| Field | Value |
|-------|-------|
| Insurer | |
| Policy Number | |
| Coverage Limit | $1M per occurrence / $2M aggregate (standard) |
| Deductible | $ |
| Annual Premium | $ |
| Policy Period | [Start Date] – [End Date] |

**Why GL matters:** Covers bodily injury or property damage. Required by many contracts and coworking spaces. Even if you work from home and meet clients remotely, some funders require it from consultants listed on grants.

---

### Cyber Liability (Recommended)

| Field | Value |
|-------|-------|
| Insurer | |
| Policy Number | |
| Coverage Limit | $ |
| Annual Premium | $ |
| Policy Period | [Start Date] – [End Date] |
| Coverage | Data breach response, notification costs, legal defense |

**Why cyber matters:** You store sensitive client financial data. A ransomware event or phishing breach affecting a client's data can trigger notification obligations and legal claims.

---

### Business Owner's Policy (BOP) — if applicable

A BOP bundles General Liability + Business Property coverage. Often cheaper than buying separately. Consider if you have business equipment (computer, camera, etc.) worth insuring.

---

## Coverage Requirements by Client Type

| Client Type | Commonly Required Coverage | Minimum Limits |
|-------------|--------------------------|---------------|
| Federal agencies / subrecipients | General Liability | $1M/$2M |
| Large foundations | Professional Liability | $1M |
| State agencies | General Liability + Workers' Comp (if employees) | Varies |
| Standard nonprofits | Usually no insurance requirement | — |

**Tip:** Some clients will request a Certificate of Insurance (COI) naming them as "additional insured." Your broker can issue this — allow 3–5 business days.

---

## Insurance Renewal Calendar

| Policy | Renewal Date | Action 60 Days Before |
|--------|-------------|----------------------|
| E&O | | Obtain renewal quote; compare carriers |
| General Liability | | Obtain renewal quote |
| Cyber | | Review coverage limits vs. current client data volume |

---

## Incident Log

*Document any potential claims or incidents here, even if no claim is filed. Early documentation protects you.*

| Date | Description | Client | Reported to Insurer? | Claim # | Resolution |
|------|-------------|--------|---------------------|---------|-----------|
| | | | | | |
