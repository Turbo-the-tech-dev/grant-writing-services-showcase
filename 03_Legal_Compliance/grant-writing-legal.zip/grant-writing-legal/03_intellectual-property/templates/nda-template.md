# Mutual Non-Disclosure Agreement

**This Mutual Non-Disclosure Agreement ("Agreement")** is entered into as of **[DATE]** between:

**Party A:** [Your Name / Business Name] ("Consultant")
**Party B:** [Client / Prospective Client Name] ("Recipient")

---

## 1. Purpose

The parties wish to explore a potential business relationship involving grant writing and consulting services ("Purpose") and may share confidential information with each other in connection with that Purpose.

---

## 2. Definition of Confidential Information

"Confidential Information" means any non-public information disclosed by either party, including but not limited to:
- Financial data, budgets, and donor information
- Program strategies, proposals, and unpublished grant documents
- Proprietary methodologies, templates, and processes
- Client lists and business strategies
- Any information marked "Confidential" or that a reasonable person would consider confidential

Confidential Information does **not** include information that:
(a) Is or becomes publicly available without breach of this Agreement
(b) Was already known to the receiving party before disclosure
(c) Is independently developed by the receiving party without use of Confidential Information
(d) Is required to be disclosed by law or regulation (with prompt advance notice to the disclosing party)

---

## 3. Obligations

Each party agrees to:
- Hold the other's Confidential Information in strict confidence
- Use it only for the Purpose described above
- Limit disclosure to employees, contractors, or advisors with a need to know, who are bound by equivalent confidentiality obligations
- Protect Confidential Information with at least the same degree of care used for its own confidential information (but no less than reasonable care)

---

## 4. No License

Nothing in this Agreement grants either party any license, right, title, or interest in the other's Confidential Information or intellectual property.

---

## 5. Return or Destruction

Upon written request or termination of the business relationship, each party will promptly return or securely destroy the other's Confidential Information and certify destruction in writing.

---

## 6. Term

This Agreement is effective as of the date above and remains in effect for **[2] years**, unless terminated earlier by mutual written agreement. Confidentiality obligations with respect to disclosed information survive expiration for an additional **3 years**.

---

## 7. Remedies

Each party acknowledges that breach of this Agreement may cause irreparable harm for which monetary damages would be inadequate, and that the non-breaching party is entitled to seek injunctive relief without bond in addition to other available remedies.

---

## 8. General

- **Governing Law:** [Your State]
- **Entire Agreement:** This Agreement supersedes all prior discussions regarding confidentiality
- **Amendments:** Must be in writing signed by both parties
- **Counterparts / Electronic Signatures:** Accepted and binding

---

## SIGNATURES

**Party A — Consultant:**
Signature: ___________________________ Date: __________
Name: [Your Name]

**Party B:**
Signature: ___________________________ Date: __________
Name: ___________________________
Title: ___________________________
Organization: ___________________________
