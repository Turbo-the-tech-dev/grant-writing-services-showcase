# Intellectual Property Policy
*[Your Business Name] | Effective: [Date]*

---

## Overview

This document outlines how intellectual property is created, owned, licensed, and protected in the course of grant consulting engagements.

---

## 1. Work Product Ownership

### Default Rule
All written grant documents (proposals, LOIs, reports, budgets, narratives) produced exclusively for a paying client **transfer to the Client upon receipt of full payment**.

### Before Full Payment
Work product created but not yet fully paid for remains the intellectual property of Consultant. Consultant may withhold delivery until payment is received.

### Shared Development
If a deliverable incorporates Client-provided content (existing narratives, data, reports), the original Client content remains Client property. The integrated document, once paid for, belongs to Client.

---

## 2. Consultant's Pre-Existing Intellectual Property

The following materials are the sole property of Consultant and are **not transferred** to any client under any engagement:

- Structural templates (proposal outlines, budget frameworks, logic model formats)
- Proprietary research methodology and funder analysis frameworks
- Standard boilerplate language and reusable narrative blocks
- Internal process documentation and checklists
- Consultant's training materials and educational content

Clients receive a **limited license** to use the final deliverable, not access to the underlying templates.

---

## 3. Copyright Notice

All original materials created by Consultant are protected by U.S. copyright law from the moment of creation. No formal registration is required for protection, but registration with the U.S. Copyright Office strengthens enforcement rights.

**Standard copyright notice for Consultant's original works:**
> © [YEAR] [Your Name / Business Name]. All rights reserved.

---

## 4. Non-Disclosure of Proprietary Methods

Consultant will not disclose proprietary frameworks, templates, or methodologies to third parties. Clients may not reverse-engineer or redistribute Consultant's underlying tools.

---

## 5. Portfolio & Case Study Rights

Consultant reserves the right to:
- List the client name and grant type in professional bios, proposals, and websites
- Reference the outcome (award amount, funder) if publicly disclosed
- Use anonymized excerpts as teaching examples

Clients may opt out of portfolio reference within 30 days of project completion by written request.

---

## 6. NDA Requests from Clients

If a client requests a mutual NDA before engagement:
- Use the NDA template in `_templates/nda-template.md`
- Have the NDA reviewed by your attorney before signing client-drafted NDAs
- Do not sign NDAs that would prevent Consultant from listing the engagement in professional materials

---

## 7. AI-Assisted Writing

If AI tools are used in drafting (e.g., Claude, ChatGPT):
- Consultant is responsible for substantial revision, accuracy, and final editorial quality
- AI-generated content is disclosed to clients upon request
- Consultant does not warrant that AI-assisted text is free of copyright claims by third parties; all AI-generated text is substantially rewritten before delivery
- Client's own AI use policies take precedence if specified in writing

---

## 8. Trademark

**Business Name:** [Your Business Name]
**Logo / Mark:** [Description]
**Status:** ☐ Unregistered (common law) ☐ State registered ☐ Federal (USPTO) — Serial #: ________

---

## Copyright Registration Log

| Work Title | Description | Date Created | Date Registered | Registration # |
|-----------|-------------|-------------|----------------|----------------|
| | | | | |
