# Subcontractor Agreement

**This Subcontractor Agreement ("Agreement")** is entered into as of **[DATE]** between:

**Contractor:** [Your Name / Business Name] ("Contractor")
**Subcontractor:** [Subcontractor Name / Business Name] ("Subcontractor")
EIN or SSN: [XX-XXXXXXX]
Business Address: [Address]

---

## 1. Services

Subcontractor agrees to perform the following specific services ("Services"):

[Describe scope clearly — e.g., "Research and draft the needs assessment section for a grant proposal to [Funder Name] for [Client Name]. Deliverable: 750–1,000 words, first draft by [Date]."]

---

## 2. Compensation

Contractor will pay Subcontractor **$[AMOUNT]** for the Services described above, payable within **[15] days** of acceptance of the completed deliverable.

☐ Fixed fee: $___________
☐ Hourly: $______/hr, estimated _____ hours, not to exceed $_______ without written approval

---

## 3. Timeline

| Deliverable | Due Date |
|------------|---------|
| [Deliverable] | [Date] |
| [Deliverable] | [Date] |

---

## 4. Independent Contractor Status

Subcontractor is an independent contractor, not an employee of Contractor. Subcontractor:
- Is responsible for all self-employment taxes on compensation received
- Will not receive employee benefits, workers' compensation, or unemployment insurance
- Retains the right to perform services for other clients
- Controls the manner and means of completing the Services

Contractor will issue a **Form 1099-NEC** for payments totaling $600 or more in a calendar year. Subcontractor must provide a completed **W-9** before first payment is made.

---

## 5. Confidentiality

Subcontractor agrees to maintain strict confidentiality regarding all client information, project details, funder relationships, and proprietary materials shared by Contractor. Subcontractor will not:
- Disclose client identity or project details to third parties
- Contact the Client directly unless expressly authorized in writing by Contractor
- Retain copies of client materials beyond project completion

This obligation survives termination of this Agreement for **3 years**.

---

## 6. Non-Solicitation

During this engagement and for **12 months** following its conclusion, Subcontractor agrees not to directly solicit or accept work from any client identified through this Agreement. If a client approaches Subcontractor directly, Subcontractor will disclose this to Contractor immediately.

---

## 7. Intellectual Property

All work product produced by Subcontractor under this Agreement is **work made for hire** and becomes the sole property of Contractor upon payment. To the extent work product does not qualify as work made for hire under applicable law, Subcontractor hereby assigns all rights to Contractor.

---

## 8. Quality & Revisions

Subcontractor agrees to:
- Deliver original work free of plagiarism
- Disclose use of AI-generated content to Contractor
- Complete up to **[1] round** of revisions at no additional charge within **[3] business days** of feedback

---

## 9. Termination

Either party may terminate this Agreement upon **[5] business days** written notice. Subcontractor will be compensated for work completed and accepted through the termination date.

---

## 10. Limitation of Liability

Subcontractor's liability to Contractor shall not exceed the total fees paid under this Agreement.

---

## 11. Governing Law

This Agreement is governed by the laws of **[Your State]**.

---

## SIGNATURES

**Contractor:**
Signature: ___________________________ Date: __________
Name: [Your Name]
Business: [Your Business Name]

**Subcontractor:**
Signature: ___________________________ Date: __________
Name: ___________________________
Business: ___________________________

---

## ATTACHMENT: W-9 STATUS

☐ W-9 received and on file
Date received: __________
EIN / SSN confirmed: ☐ Yes
