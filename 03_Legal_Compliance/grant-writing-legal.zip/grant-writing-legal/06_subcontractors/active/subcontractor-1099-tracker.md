# Subcontractor & 1099 Tracker

## Active / Recent Subcontractors

| Name | Business Name | EIN / SSN | W-9 on File | Services | YTD Paid | 1099 Required (≥$600)? | 1099 Issued | Date Issued |
|------|--------------|-----------|------------|---------|----------|----------------------|------------|------------|
| | | | ☐ Yes ☐ No | | $ | ☐ Yes ☐ No | ☐ Yes ☐ No | |
| | | | ☐ Yes ☐ No | | $ | ☐ Yes ☐ No | ☐ Yes ☐ No | |

---

## 1099-NEC Filing Checklist (Due January 31)

| Step | Done? | Notes |
|------|-------|-------|
| Confirm all subs paid ≥ $600 in calendar year | ☐ | |
| Collect / verify W-9 for each sub | ☐ | Never pay without W-9 on file |
| Reconcile totals in accounting software | ☐ | |
| File 1099-NEC with IRS (electronic if ≥ 10 forms) | ☐ | Via IRS FIRE system or payroll provider |
| Send copy to each subcontractor by Jan 31 | ☐ | |
| File 1096 transmittal (if filing paper) | ☐ | |
| Retain copies for 4 years | ☐ | |

**IRS 1099-NEC deadline:** January 31 (both to recipient and IRS)
**California 592-B (CA withholding):** Required if subcontractor is a CA nonresident and payment > $1,500

---

## Subcontractor Performance Notes

| Name | Project | Strengths | Issues | Rehire? |
|------|---------|-----------|--------|--------|
| | | | | ☐ Yes ☐ No |
