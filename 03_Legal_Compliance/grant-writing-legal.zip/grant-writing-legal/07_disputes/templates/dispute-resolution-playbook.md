# Dispute Resolution — Templates & Log

---

## Dispute Prevention Checklist

The best dispute is the one that never happens. Before each project:

☐ Signed contract in place before any work begins
☐ Scope is specific — deliverables, revision rounds, deadlines named explicitly
☐ No-guarantee clause present and verbally acknowledged
☐ Payment schedule and late fee policy confirmed
☐ Client expectations conversation held (realistic funder timelines, win rates)
☐ Change order process explained to client

---

## Dispute Log

| Date | Client | Issue Description | Amount in Dispute | Resolution | Resolved Date | Attorney Involved? |
|------|--------|------------------|------------------|-----------|--------------|-------------------|
| | | | $ | | | ☐ Yes ☐ No |

---

## Escalation Ladder

**Step 1 — Direct Conversation (within 48 hours of issue surfacing)**
Call or video meeting. Acknowledge the concern, gather facts, propose a solution. Document the conversation in an email follow-up immediately after.

**Step 2 — Formal Written Notice (if Step 1 unresolved within 7 days)**
Send a formal email summarizing the dispute, Consultant's position, and a proposed resolution with a response deadline. Save all correspondence.

**Step 3 — Mediation (if Step 2 unresolved within 30 days)**
Per contract terms, initiate mediation. Contact your attorney before this step.

**Step 4 — Legal Action**
Consult attorney. Evaluate cost/benefit. Small claims court ($12,500 limit in California) is often practical for fee disputes without attorney.

---

## Past-Due Invoice Sequence

### Day 1 after due date:
*Friendly reminder — assume good faith*

> Subject: Invoice [#] — Friendly Reminder
>
> Hi [Name], just a quick note that Invoice [#] for $[Amount], due [Date], doesn't appear to have been processed yet. Could you confirm receipt and let me know if there's anything needed on your end? Happy to resend if helpful.

---

### Day 15 after due date:
*Formal follow-up*

> Subject: Invoice [#] — Payment Follow-Up
>
> Hi [Name], I'm following up again on Invoice [#] for $[Amount], now [X] days past due. Per our agreement, a late fee of 1.5% per month is accruing on the balance. Please arrange payment by [specific date] to avoid further charges. If there's a problem I'm unaware of, please reach out so we can resolve it.

---

### Day 30 after due date:
*Formal demand / notice of dispute*
Use the template below.

---

## Formal Demand Letter Template

[Your Name / Business Name]
[Address]
[Date]

Via Email and Certified Mail

[Client Contact Name]
[Client Organization]
[Address]

**RE: Formal Demand for Payment — Invoice [#] — $[AMOUNT]**

Dear [Name],

This letter constitutes formal notice that [Client Organization] owes [Your Business Name] the sum of **$[AMOUNT]**, representing Invoice [#] dated [Date] for grant consulting services rendered under our Service Agreement dated [Date].

Payment was due on [Date] and remains outstanding as of [Today's Date], now [X] days overdue. Despite prior written follow-up on [dates], no payment has been received.

Pursuant to Section [X] of our Agreement, late fees of 1.5% per month have accrued, bringing the total now owed to **$[UPDATED TOTAL]**.

**Demand is hereby made for full payment of $[AMOUNT] within 10 business days of the date of this letter**, no later than [DEADLINE DATE].

If payment is not received by that date, I will pursue all available legal remedies, including filing a claim in Small Claims Court, reporting to credit agencies, and seeking recovery of attorney fees as provided in our Agreement.

This letter is not intended to waive any rights or remedies available under the Agreement or applicable law.

Sincerely,

[Your Signature]
[Your Name]
[Your Business Name]
[Your Contact Information]
