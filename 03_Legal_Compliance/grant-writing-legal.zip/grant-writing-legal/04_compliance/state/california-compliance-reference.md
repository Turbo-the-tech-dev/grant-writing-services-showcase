# California State Compliance Reference
*For consultants operating in California*

---

## Business Compliance — Solo Consultant / LLC

### Annual LLC Requirements (California)

| Requirement | Agency | Due | Amount |
|-------------|--------|-----|--------|
| Statement of Information (biennial) | CA Secretary of State | Every 2 years (month of formation) | $20 |
| Minimum Franchise Tax | CA Franchise Tax Board | 15th day of 4th month after tax year | $800/year |
| CA LLC Fee (if gross receipts > $250K) | CA FTB | Same as above | $900–$11,790 |
| Estimated Tax Payments | CA FTB | Quarterly | Based on income |

> Note: New LLCs are exempt from the $800 minimum franchise tax in their **first taxable year** (AB 85, effective 2021).

### Fictitious Business Name (DBA)
- Required if operating under any name other than your legal name
- File with the county clerk where your principal place of business is located
- Must be published in a general circulation newspaper for 4 consecutive weeks within 30 days of filing
- Expires after 5 years; must be renewed

---

## California Consumer Privacy Act (CCPA) / CPRA

### Does CCPA Apply to Your Business?

CCPA applies to for-profit businesses that:
- Have annual gross revenues > $25 million, **OR**
- Buy, sell, or share personal information of 100,000+ consumers/households annually, **OR**
- Derive 50%+ of revenue from selling/sharing personal information

**Most solo grant consultants do not meet these thresholds.** However, it is good practice to:
- Maintain a simple privacy policy describing how you collect and use client contact data
- Not sell or share client information with third parties
- Honor requests from individuals to delete their contact information
- Use a privacy policy template (see `08_privacy-data/`)

---

## AB 5 / AB 2257 — Independent Contractor Classification

California's AB 5 (codified as Labor Code Section 2775) applies the **ABC Test** to determine if workers are employees or independent contractors. This affects two scenarios:

### 1. You as the Consultant (Client hiring you)
Nonprofits and businesses hiring you must confirm you meet the ABC Test:
- **(A)** You are free from control and direction in performance of services
- **(B)** You perform work outside the client's usual course of business (grant writing = outside scope for most nonprofits ✓)
- **(C)** You are customarily engaged in an independently established trade

Grant writing typically qualifies as outside the usual course of business for most nonprofits, supporting independent contractor status.

### 2. Subcontractors You Hire
Apply the same ABC Test to anyone you subcontract work to. If they fail the test, they may be classified as your employees — triggering payroll tax, workers' comp, and benefits obligations.

**Safe practice:** Use written subcontractor agreements, ensure subs have their own business operations, and do not control the manner of their work.

---

## California Nonprofit Client Compliance Notes

When writing grants for California nonprofits, flag these common issues:

| Issue | Reference |
|-------|---------|
| Charitable solicitation registration | CA Registry of Charitable Trusts (must be current to receive grants) |
| RRF-1 / Form 990 filings current | Required for charitable registration |
| BOE-100-B (property tax exemption) | If client owns property |
| Workers' comp coverage | Required for any employee, even part-time |
| Conflict of interest policy | Required for most foundation grants |

---

## Useful California State Portals

| Portal | URL | Purpose |
|--------|-----|---------|
| CA Secretary of State | bizfileonline.sos.ca.gov | Entity status, filings |
| CA FTB | ftb.ca.gov | Franchise tax, income tax |
| CA Registry of Charitable Trusts | oag.ca.gov/charities | Nonprofit registration lookup |
| CA DIR | dir.ca.gov | Labor law, workers' comp |
| CA EDD | edd.ca.gov | Payroll taxes (if you hire employees) |
