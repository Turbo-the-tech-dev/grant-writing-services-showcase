# Federal Grant Compliance Reference
*For grant writers working with clients that receive or seek federal funding*

> This is a reference guide, not legal advice. Requirements vary by award type, agency, and client organization.

---

## The Uniform Guidance (2 CFR Part 200)

The primary federal regulation governing grants to nonprofits, state/local governments, and universities. Key areas affecting grant budgets and narratives:

### Cost Principles (Subpart E)

Costs must be:
- **Allowable** — permitted by the award terms and not prohibited by regulation
- **Allocable** — appropriately charged to the program it benefits
- **Reasonable** — consistent with what a prudent person would pay
- **Consistently treated** — applied the same way across federal and non-federal programs

### Common Cost Issues to Flag in Client Budgets

| Issue | Guidance |
|-------|---------|
| Unallowable costs (lobbying, alcohol, entertainment) | Must be excluded from federal budgets |
| Indirect cost rate | Requires either a negotiated rate (NICRA) or de minimis 10% of MTDC |
| Salary caps | NIH, for example, caps salary at the Executive Level II rate |
| Consultant rates | Must be reasonable; rates > $650/day often require justification |
| Prior approval requirements | Equipment purchases, budget changes >10%, key personnel changes |

### De Minimis Indirect Cost Rate
Organizations without a NICRA may use **10% of Modified Total Direct Costs (MTDC)**.
MTDC excludes: equipment, capital expenditures, patient care, rental costs, tuition, and subawards > $25,000.

---

## SAM.gov Requirements

Federal grantees and subrecipients must be registered in SAM.gov (System for Award Management).
- Registration is **free** — warn clients against paid SAM.gov registration services
- Must be renewed **annually**
- Lapse in registration can delay or disqualify awards
- UEI (Unique Entity Identifier) replaced DUNS numbers in April 2022

---

## Grant Ethics Standards

### Grant Professionals Association (GPA) Code of Ethics
Key provisions relevant to consultants:
- Do not accept compensation contingent on grant award (percentage of award)
- Disclose conflicts of interest
- Represent credentials and experience accurately
- Protect confidential client information

### Association of Fundraising Professionals (AFP) Code
- Prohibits percentage-based compensation for fundraising (including grants)
- Applies if your clients use AFP as their professional standard

### Why This Matters Legally
Many funders (especially federal agencies) ask applicants to certify they have not used contingency-fee grant writers. Violating this can result in disqualification or award termination.

---

## Lobbying Restrictions

Federal grantees must certify they will not use federal funds for lobbying. This also affects grant writers:
- Do not draft lobbying content as part of a federally funded scope
- Do not include lobbying activities in any federal budget line items
- Certifications under Section 319 (Byrd Amendment) apply to awards ≥ $100,000

---

## Conflict of Interest

When writing grants, flag these situations to clients:
- Board members employed by funder
- Consultant has prior relationship with funder staff
- Client purchasing goods/services from board member vendors

Conflicts do not necessarily disqualify — but they must be disclosed in writing to the funder before submission.

---

## Client Eligibility Verification Checklist

Before submitting on a client's behalf, confirm:

☐ Organization is in good standing with state (check Secretary of State)
☐ 501(c)(3) status current (check IRS Tax Exempt Organization Search)
☐ SAM.gov registration active (if federal)
☐ No debarment or suspension (check SAM.gov exclusions)
☐ DUNS/UEI matches legal entity name on application
☐ Indirect cost rate documented (NICRA or de minimis election)
☐ Most recent audited financials available (required for awards ≥ $750K)
☐ Organization meets funder's geographic or population eligibility

---

## Key Federal Agency Grant Portals

| Agency | Portal | Notes |
|--------|--------|-------|
| All federal grants | grants.gov | Application submission |
| NIH | grants.nih.gov / era.commons | Biomedical research |
| DOE | eere.energy.gov | Energy programs |
| HHS | hhs.gov/grants | Health & human services |
| DOL | dol.gov/agencies/eta/grants | Workforce |
| NEA | arts.gov | Arts |
| IMLS | imls.gov | Libraries & museums |
| USDA Rural Dev. | rd.usda.gov | Rural communities |
