# Grant Writing Legal Compliance — System Overview

Legal compliance and documentation system for a solo grant writing consultant.

> ⚠️ This system is an organizational and reference tool. It does not constitute legal advice.
> Consult a licensed attorney for your specific situation.

---

## Directory Structure

```
grant-writing-legal/
├── 01_business-formation/    → LLC/DBA docs, licenses, EIN, registered agent
├── 02_contracts/             → Client service agreements, SOWs, amendments
├── 03_intellectual-property/ → Copyright notices, NDA templates, portfolio policy
├── 04_compliance/            → Federal, state, and client grant regulations
├── 05_insurance/             → E&O, general liability, policies, renewals
├── 06_subcontractors/        → 1099 agreements, W-9s, confidentiality terms
├── 07_disputes/              → Dispute resolution log, demand letter templates
├── 08_privacy-data/          → Data handling policy, client data agreements
└── _templates/               → Master template library
```

---

## Annual Legal Compliance Checklist

| Task | Frequency | Owner | Due |
|------|-----------|-------|-----|
| Renew business license | Annual | You | [Date] |
| Review & update service agreement template | Annual | You + Attorney | Q1 |
| Confirm E&O insurance renewal | Annual | You | [Policy Date] |
| File annual report (if LLC) | Annual | You / Registered Agent | [State Due Date] |
| Issue 1099-NECs to subcontractors | Annual | You / Bookkeeper | Jan 31 |
| Collect W-9s from new subs before first payment | Per engagement | You | Before payment |
| Review client contracts for scope creep | Quarterly | You | Each quarter |
| Audit data storage & client file retention | Annual | You | Q4 |
| Update privacy policy if services/tools changed | As needed | You | Rolling |

---

## Key Legal Risks for Solo Grant Writers

1. **Scope creep without contract amendments** — undocumented extra work = unpaid work or disputes
2. **Contingency fee arrangements** — prohibited by most grant ethics standards (GPA, AFP)
3. **Unauthorized practice** — avoid providing legal, accounting, or fiduciary advice
4. **Client data breach** — storing sensitive nonprofit financials requires basic security hygiene
5. **IP ownership disputes** — unclear contract language on who owns the written work product
6. **Subcontractor misclassification** — paying subs without proper W-9s or 1099s creates tax liability
7. **No-guarantee clause omissions** — without it, dissatisfied clients may claim breach of contract

---

## Emergency Contact List

| Role | Name | Phone | Email |
|------|------|-------|-------|
| Business Attorney | | | |
| CPA / Tax Advisor | | | |
| Insurance Broker | | | |
| Registered Agent | | | |
