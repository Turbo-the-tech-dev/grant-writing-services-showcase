# Client Data Privacy & Security Policy
*[Your Business Name] | Effective: [Date]*

---

## Overview

As a grant writing consultant, you handle sensitive organizational data including financial statements, donor records, program data, and sometimes personally identifiable information (PII) of beneficiaries. This policy establishes how that data is collected, stored, used, and disposed of.

---

## 1. Types of Data Collected

| Data Type | Examples | Sensitivity |
|-----------|---------|------------|
| Organizational financials | Audits, 990s, budgets | High |
| Program data | Participant counts, outcomes | Medium |
| Donor information | Names, gift amounts | High |
| Beneficiary data | Demographics, case data | Very High |
| Contact information | Staff names, emails, phones | Low |
| Grant history | Prior awards, declined applications | Medium |

---

## 2. Data Collection Principles

- Collect only what is necessary to perform contracted services
- Do not retain data longer than required
- Do not use client data for any purpose outside the engagement
- Do not share client data with third parties without written consent

---

## 3. Data Storage Standards

### Cloud Storage
- Use only reputable, password-protected cloud platforms (Google Drive, Dropbox Business, OneDrive)
- Enable two-factor authentication (2FA) on all storage platforms
- Store client files in dedicated, clearly labeled folders
- Do not use personal storage accounts for client data

### Local Storage
- Store sensitive files on encrypted drives only
- Do not save client files on shared or public computers
- Enable full-disk encryption on your primary work device

### Email
- Do not send financial statements, tax documents, or beneficiary data via unencrypted email
- Use secure file transfer (Google Drive share link, Dropbox link) for sensitive documents
- Do not forward client emails to personal accounts

### Physical Documents
- Minimize printing of sensitive materials
- Lock up any printed sensitive documents
- Shred (cross-cut) before disposal

---

## 4. Client Data Inventory

| Client | Data Types Held | Storage Location | Retention Period | Last Reviewed |
|--------|----------------|-----------------|-----------------|--------------|
| | | | | |

---

## 5. Data Retention & Deletion

| Document Type | Retention Period | Disposal Method |
|--------------|-----------------|----------------|
| Signed contracts | 7 years | Secure delete / shred |
| Invoices & financial records | 7 years | Secure delete / shred |
| Grant drafts & deliverables | 3 years post-project | Secure delete |
| Client financial statements | Duration of engagement + 1 year | Secure delete |
| Beneficiary / PII data | Duration of engagement only | Immediate secure delete post-project |
| Email correspondence | 3 years | Archive then delete |

**Secure delete tools:** Eraser (Windows), Secure Empty Trash (Mac), or certified cloud deletion

---

## 6. Breach Response Protocol

If you discover or suspect a data breach (unauthorized access, lost device, ransomware, phishing):

**Within 24 hours:**
☐ Document what happened (what data, when discovered, likely exposure)
☐ Change all passwords for affected accounts
☐ Enable 2FA if not already active
☐ Contact your cyber insurance carrier

**Within 72 hours:**
☐ Notify affected clients in writing (per contract and good practice)
☐ Assess whether state breach notification law applies (California requires notice if >500 CA residents affected)
☐ Consult attorney if significant data was exposed

**Template Breach Notification Email:**

> Subject: Important Notice Regarding Your Data
>
> Dear [Client Contact],
>
> I am writing to inform you that on [Date], I became aware of a security incident that may have involved information related to your organization shared with me for grant consulting purposes.
>
> What happened: [Brief, factual description]
> What information may be involved: [Types of data]
> What I am doing: [Steps taken to contain and investigate]
> What you can do: [Any recommended actions for the client]
>
> I take the security of your information very seriously and sincerely apologize for this incident. Please contact me at [email/phone] with any questions.
>
> [Your Name]

---

## 7. Third-Party Tools

Tools used in the course of services that may process client data:

| Tool | Purpose | Data Processed | Privacy Policy |
|------|---------|---------------|----------------|
| Google Workspace | Docs, email, file storage | All client files | google.com/privacy |
| Notion | Project management | Project notes | notion.so/privacy |
| Zoom | Client calls | Meeting recordings (if any) | zoom.us/privacy |
| Claude (Anthropic) | Drafting assistance | Content only — do not input PII | anthropic.com/privacy |
| Grammarly | Writing review | Draft text | grammarly.com/privacy |

**Caution with AI tools:** Do not input beneficiary names, SSNs, donor information, or other PII into AI writing assistants. Input only anonymized program descriptions and organizational data.

---

## 8. Client Data Agreement (Short Form)

*Include this clause in your service agreement or as a standalone addendum for high-sensitivity engagements:*

> Consultant agrees to: (a) store Client data only on password-protected, encrypted platforms; (b) use Client data solely to perform contracted services; (c) not disclose Client data to third parties without written consent; (d) notify Client within 72 hours of any known or suspected data security incident involving Client information; and (e) securely delete all Client data within [90] days of project completion upon written request.
